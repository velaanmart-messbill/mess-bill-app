
import streamlit as st
import pandas as pd
import sqlite3, os, re, json, hashlib
from datetime import datetime, date
from sqlite3 import Connection
import pdfplumber
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

DB_PATH = "data.db"
UPLOAD_DIR = "uploads"

def get_conn() -> Connection:
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password_hash TEXT,
        created_at TEXT
    )
    """)
    c.execute("""
    CREATE TABLE IF NOT EXISTS bills (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        month INTEGER,
        year INTEGER,
        total_invoice REAL,
        total_fixed REAL,
        total_expenses REAL,
        num_students INTEGER,
        per_student REAL,
        metadata TEXT,
        created_at TEXT
    )
    """)
    c.execute("""
    CREATE TABLE IF NOT EXISTS invoices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        bill_id INTEGER,
        filename TEXT,
        total REAL,
        raw_text TEXT,
        created_at TEXT
    )
    """)
    c.execute("""
    CREATE TABLE IF NOT EXISTS fixed_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        bill_id INTEGER,
        name TEXT,
        amount REAL
    )
    """)
    conn.commit()
    conn.close()

def hash_password(password: str, salt: str=None) -> str:
    if salt is None:
        salt = "static_salt_v1"
    return hashlib.sha256((salt + password).encode('utf-8')).hexdigest()

def create_user(username: str, password: str) -> bool:
    conn = get_conn(); c = conn.cursor()
    try:
        c.execute("INSERT INTO users (username, password_hash, created_at) VALUES (?, ?, ?)", 
                  (username, hash_password(password), datetime.utcnow().isoformat()))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False
    finally:
        conn.close()

def authenticate(username: str, password: str):
    conn = get_conn(); c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username = ?", (username,))
    row = c.fetchone()
    conn.close()
    if row and row['password_hash'] == hash_password(password):
        return dict(row)
    return None

def extract_amounts_from_text(text: str):
    pattern = r'₹?\s*([0-9\,]+(?:\.\d{1,2})?)'
    matches = re.findall(pattern, text.replace('\n',' '))
    amounts = []
    for m in matches:
        cleaned = m.replace(',', '').strip()
        try:
            val = float(cleaned)
            if val >= 1:
                amounts.append(val)
        except:
            continue
    return amounts

def parse_pdf_sum(file_path: str):
    total = 0.0
    raw = ''
    try:
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                text = page.extract_text() or ''
                raw += text + '\n'
        amounts = extract_amounts_from_text(raw)
        if amounts:
            total = max(amounts)
        else:
            total = 0.0
        return total, raw
    except Exception as e:
        return 0.0, ''

def export_bill_pdf(bill_row, invoices_rows, fixed_items_rows, out_path):
    c = canvas.Canvas(out_path, pagesize=A4)
    width, height = A4
    x = 40; y = height - 40
    c.setFont('Helvetica-Bold', 14)
    c.drawString(x, y, 'Mess Bill Summary')
    c.setFont('Helvetica', 10)
    y -= 30
    c.drawString(x, y, f"Billing Period: {bill_row['month']:02d}/{bill_row['year']}")
    y -= 18
    c.drawString(x, y, f"Generated: {bill_row['created_at']}")
    y -= 24
    c.drawString(x, y, f"Total Invoice Amount: ₹{bill_row['total_invoice']:.2f}")
    y -= 16
    c.drawString(x, y, f"Total Fixed Expenses: ₹{bill_row['total_fixed']:.2f}")
    y -= 16
    c.drawString(x, y, f"Total Expenses: ₹{bill_row['total_expenses']:.2f}")
    y -= 16
    c.drawString(x, y, f"Number of Students: {bill_row['num_students']}")
    y -= 20
    c.setFont('Helvetica-Bold', 12)
    c.drawString(x, y, f"Per Student: ₹{bill_row['per_student']:.2f}")
    y -= 24
    c.setFont('Helvetica-Bold', 11)
    c.drawString(x, y, 'Invoice Breakdown:')
    c.setFont('Helvetica', 10)
    y -= 16
    for inv in invoices_rows:
        if y < 80:
            c.showPage(); y = height - 40
        c.drawString(x, y, f"- {inv['filename']}: ₹{inv['total']:.2f}")
        y -= 14
    y -= 8
    c.setFont('Helvetica-Bold', 11)
    c.drawString(x, y, 'Fixed Items:')
    c.setFont('Helvetica', 10)
    y -= 16
    for fx in fixed_items_rows:
        if y < 80:
            c.showPage(); y = height - 40
        c.drawString(x, y, f"- {fx['name']}: ₹{fx['amount']:.2f}")
        y -= 14
    c.save()

st.set_page_config(page_title='Mess Bill - Multiuser', layout='wide')
init_db()
if 'user' not in st.session_state:
    st.session_state.user = None

st.title('🧾 Mess Bill Manager (Multi-user)')

if st.session_state.user is None:
    st.sidebar.header('Login / Register')
    mode = st.sidebar.selectbox('Mode', ['Login', 'Register'])
    username = st.sidebar.text_input('Username')
    password = st.sidebar.text_input('Password', type='password')
    if mode == 'Register':
        if st.sidebar.button('Create account'):
            ok = create_user(username, password)
            if ok:
                st.sidebar.success('Account created — please login.')
            else:
                st.sidebar.error('Username already exists.')
    else:
        if st.sidebar.button('Login'):
            user = authenticate(username, password)
            if user:
                st.session_state.user = user
                st.experimental_rerun()
            else:
                st.sidebar.error('Invalid credentials.')
    st.info('Register a new account in the Register mode, then login. Passwords are hashed (basic). For production, use stronger hashing & HTTPS.')
    st.stop()

st.sidebar.success(f"Logged in as: {st.session_state.user['username']}")
if st.sidebar.button('Logout'):
    st.session_state.user = None
    st.experimental_rerun()

conn = get_conn(); c = conn.cursor()

tab = st.sidebar.radio('Go to', ['New Bill', 'History', 'Settings'])

if tab == 'New Bill':
    st.header('Create new monthly bill')
    col1, col2 = st.columns(2)
    with col1:
        month = st.selectbox('Month', list(range(1,13)), index=date.today().month-1, format_func=lambda m: date(2000,m,1).strftime('%B'))
    with col2:
        year = st.number_input('Year', min_value=2000, max_value=2100, value=date.today().year)
    st.subheader('Upload Invoices (CSV / Excel / PDF)')
    uploaded = st.file_uploader('Upload invoice files (multiple)', accept_multiple_files=True, type=['csv','xlsx','xls','pdf'])
    invoice_sum = 0.0
    invoice_rows = []
    if uploaded:
        for u in uploaded:
            fname = u.name
            save_path = os.path.join(UPLOAD_DIR, f"{int(datetime.utcnow().timestamp())}_{fname}")
            with open(save_path, 'wb') as f:
                f.write(u.getbuffer())
            inv_total = 0.0; raw = ''
            if fname.lower().endswith('.pdf'):
                inv_total, raw = parse_pdf_sum(save_path)
            else:
                try:
                    if fname.lower().endswith('.csv'):
                        df = pd.read_csv(save_path)
                    else:
                        df = pd.read_excel(save_path)
                    amt_col = None
                    for c in df.columns:
                        if c.strip().lower() in ['amount','total','price','value','amt']:
                            amt_col = c; break
                    if amt_col is None and df.shape[1] >= 2:
                        amt_col = df.columns[-1]
                    if amt_col:
                        inv_total = pd.to_numeric(df[amt_col], errors='coerce').fillna(0.0).sum()
                    else:
                        inv_total = 0.0
                    raw = df.to_csv(index=False)
                except Exception as e:
                    inv_total = 0.0; raw = ''
            invoice_sum += inv_total
            invoice_rows.append({'filename': fname, 'total': float(inv_total), 'raw': raw})
        st.write(f"Detected total from uploaded invoices: ₹{invoice_sum:,.2f}")
        st.dataframe(pd.DataFrame(invoice_rows))

    st.subheader('Fixed expenses (salaries etc.)')
    cook = st.number_input('Cook salary (₹)', min_value=0.0, value=0.0, step=100.0)
    helpers = st.number_input('Helpers salary (₹)', min_value=0.0, value=0.0, step=100.0)
    caretaker = st.number_input('Caretaker salary (₹)', min_value=0.0, value=0.0, step=100.0)
    st.markdown('**Add custom fixed items**')
    fx_name = st.text_input('Name (e.g., Gas, Rent)', key='fx_name')
    fx_amount = st.number_input('Amount (₹)', min_value=0.0, value=0.0, key='fx_amount', step=50.0)
    if st.button('Add custom item'):
        if fx_name and fx_amount > 0:
            if 'custom_fx' not in st.session_state:
                st.session_state.custom_fx = []
            st.session_state.custom_fx.append({'name': fx_name, 'amount': float(fx_amount)})
            st.experimental_rerun()
    custom_fx = st.session_state.get('custom_fx', [])
    if custom_fx:
        st.write('Custom Fixed Items:')
        st.dataframe(pd.DataFrame(custom_fx))

    total_fixed = cook + helpers + caretaker + sum([x['amount'] for x in custom_fx])
    st.write(f"Total fixed expenses: ₹{total_fixed:,.2f}")

    st.subheader('Students & Calculation')
    students = st.number_input('Number of students', min_value=1, value=50, step=1)
    rounding = st.selectbox('Round per-student to', [0,1,2], index=0)
    total_expenses = invoice_sum + total_fixed
    per_student = round(total_expenses / students, rounding)
    st.metric('Total Expenses', f"₹{total_expenses:,.2f}", help='Invoices + fixed items')
    st.metric('Per Student', f"₹{per_student:.{rounding}f}")

    if st.button('Save bill to history'):
        metadata = json.dumps({'custom_fixed': custom_fx})
        c.execute("INSERT INTO bills (user_id, month, year, total_invoice, total_fixed, total_expenses, num_students, per_student, metadata, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
                  (st.session_state.user['id'], month, year, float(invoice_sum), float(total_fixed), float(total_expenses), int(students), float(per_student), metadata, datetime.utcnow().isoformat()))
        bill_id = c.lastrowid
        for inv in invoice_rows:
            c.execute("INSERT INTO invoices (bill_id, filename, total, raw_text, created_at) VALUES (?,?,?,?,?)", (bill_id, inv['filename'], float(inv['total']), inv['raw'], datetime.utcnow().isoformat()))
        for fx in custom_fx:
            c.execute("INSERT INTO fixed_items (bill_id, name, amount) VALUES (?,?,?)", (bill_id, fx['name'], float(fx['amount'])))
        conn.commit()
        st.success('Saved bill. You can view it in History.')
        st.session_state.custom_fx = []
        st.experimental_rerun()

elif tab == 'History':
    st.header('Saved Bills')
    c.execute('SELECT * FROM bills WHERE user_id = ? ORDER BY year DESC, month DESC, created_at DESC', (st.session_state.user['id'],))
    bills = c.fetchall()
    if not bills:
        st.info('No saved bills yet. Create one in New Bill.')
    else:
        df = pd.DataFrame([dict(x) for x in bills])
        df['period'] = df.apply(lambda r: f"{int(r['month']):02d}/{int(r['year'])}", axis=1)
        st.dataframe(df[['id','period','total_expenses','per_student','created_at']].rename(columns={'total_expenses':'Total Expenses','per_student':'Per Student'}), use_container_width=True)
        sel = st.number_input('Enter bill id to view/export', min_value=0, value=0, step=1)
        if sel > 0:
            c.execute('SELECT * FROM bills WHERE id = ? AND user_id = ?', (sel, st.session_state.user['id']))
            br = c.fetchone()
            if not br:
                st.error('Bill not found or not authorized.')
            else:
                bill = dict(br)
                st.subheader('Bill Summary')
                st.write(f"Period: {int(bill['month']):02d}/{int(bill['year'])}")
                st.write(f"Total Invoice: ₹{bill['total_invoice']:.2f}")
                st.write(f"Total Fixed: ₹{bill['total_fixed']:.2f}")
                st.write(f"Total Expenses: ₹{bill['total_expenses']:.2f}")
                st.write(f"Per Student: ₹{bill['per_student']:.2f}")
                c.execute('SELECT * FROM invoices WHERE bill_id = ?', (sel,))
                invs = [dict(x) for x in c.fetchall()]
                c.execute('SELECT * FROM fixed_items WHERE bill_id = ?', (sel,))
                fxs = [dict(x) for x in c.fetchall()]
                if invs:
                    st.write('Invoices:'); st.dataframe(pd.DataFrame(invs))
                if fxs:
                    st.write('Fixed items:'); st.dataframe(pd.DataFrame(fxs))

                if st.button('Export PDF'):
                    out_path = f"bill_{sel}.pdf"
                    export_bill_pdf(bill, invs, fxs, out_path)
                    with open(out_path, 'rb') as f:
                        st.download_button('Download bill PDF', f.read(), file_name=out_path, mime='application/pdf')

else:
    st.header('Settings & Info')
    st.write('Account: ', st.session_state.user['username'])
    st.write('DB path:', DB_PATH)
    st.write('Uploads directory:', UPLOAD_DIR)
    st.markdown('**Security note:** This MVP stores passwords using a basic SHA256 hash with a static salt. For production, use a proper password hashing algorithm and TLS.')

conn.close()
