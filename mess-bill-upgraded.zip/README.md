
# Mess Bill Manager - Upgraded (Streamlit)

Ready-to-deploy Streamlit app for managing mess/canteen/corporate kitchen bills with:
- Multi-user authentication (basic)
- Upload invoices (CSV, Excel, PDF)
- Automatic PDF parsing (heuristic) using pdfplumber
- Save monthly bills to SQLite history
- Export bill summary as PDF (ReportLab)

## Files
- app.py : main Streamlit app
- init_db.py : initialize the SQLite database `data.db`
- requirements.txt : Python dependencies
- uploads/ : directory where uploaded invoices are saved

## Run locally
```bash
pip install -r requirements.txt
python init_db.py   # initializes data.db
streamlit run app.py
```

## Deploy
1. Push repo to GitHub.
2. Use Streamlit Community Cloud (share.streamlit.io) — point to `app.py` as entry.
3. Or use Hugging Face Spaces (choose Streamlit runtime).
4. For production, use a proper password hashing algorithm and host on a secure server (HTTPS).
